import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Dashboard from '../Dashboard';
import { MemoryRouter } from 'react-router-dom';

describe('Dashboard Integration', () => {
  it('renders recent expenses and sidebar buttons', () => {
    render(
      <MemoryRouter>
        <Dashboard />
      </MemoryRouter>
    );

    expect(screen.getByText(/Recent Expenses/i)).toBeInTheDocument();

    fireEvent.click(screen.getByText(/Home/i));
    fireEvent.click(screen.getByText(/Profile/i));
    fireEvent.click(screen.getByText(/Settings/i));
  });

  it('renders and interacts with quick access buttons', () => {
    render(
      <MemoryRouter>
        <Dashboard />
      </MemoryRouter>
    );

    fireEvent.click(screen.getByText(/Add Expense/i));
    fireEvent.click(screen.getByText(/Remove Expense/i));
  });
});
